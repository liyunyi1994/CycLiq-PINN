clc
clear

epoch = 3000;

rng('shuffle');
randE = rand(3*(epoch+1),1);
dire  = -1;

p     = zeros(3*(epoch+1),1);
s     = zeros(3*(epoch+1),6);
dv    = zeros(3*(epoch+1),1);
de    = zeros(3*(epoch+1),6);
evir  = zeros(3*(epoch+1),1);
evre  = zeros(3*(epoch+1),1);
evc   = zeros(3*(epoch+1),1);
rmono = zeros(3*(epoch+1),1);
Mm    = zeros(3*(epoch+1),1);
alpha = zeros(3*(epoch+1),6);
Lp    = zeros(3*(epoch+1),1);
nor   = zeros(3*(epoch+1),6);
Dre   = zeros(3*(epoch+1),1);
Dir   = zeros(3*(epoch+1),1);

for i = 1:3

p0 = 100*i;

S   = zeros(3,3);
E   = zeros(3,3);
dS  = zeros(3,3);
Int = zeros(14,1);

S(1,1) = -p0;
S(2,2) = -p0;
S(3,3) = -p0;

p((epoch+1)*(i-1)+1) = p0;

for kk = 1:epoch
ID = (epoch+1)*(i-1)+kk+1;
E0 = E;
for ii = 1:10
    dS(1,1) = dire*randE(ID)*1e-3*p0;
    [dE,Int,Lp0,nor0,Dre0,Dir0] = GetStrainCycLiq(E,S,dS,Int);
    S = S+dS;
    E = E+dE;
end
dE = E-E0;

p(ID)       = -trace(S)/3;
s(ID,:)     = GetDev(S);
dv(ID)      = trace(dE);
de(ID,:)    = GetDev(dE);
evir(ID)    = Int(1);
evre(ID)    = Int(2);
evc(ID)     = Int(3);
rmono(ID)   = Int(4);
Mm(ID)      = Int(5);
alpha(ID,:) = [Int(6),Int(10),Int(14),Int(7),Int(11),Int(12)];
Lp(ID)      = Lp0;
nor(ID,:)   = [nor0(1,1),nor0(2,2),nor0(3,3),nor0(1,2),nor0(2,3),nor0(3,1)];
Dre(ID)     = Dre0;
Dir(ID)   = Dir0;

end

end

clear p0 q0 kk ii E S E0 dE dS Lp0 nor0 Dre0 Dir0 ID

save DataInTriCD

function dev = GetDev(ten)
dev    = zeros(1,6);
mean   = trace(ten)/3;
dev(1) = ten(1,1)-mean;
dev(2) = ten(2,2)-mean;
dev(3) = ten(3,3)-mean;
dev(4) = ten(1,2);
dev(5) = ten(2,3);
dev(6) = ten(3,1);
end