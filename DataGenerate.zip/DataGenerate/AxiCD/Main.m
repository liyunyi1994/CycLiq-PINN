clc
clear

rng('shuffle');
randE = rand(1e6,1);
dire  = -1;

inf = zeros(2,1);
sup = zeros(2,1);

ID = 0;

for ii = 1:2

pin = 100*(2*ii-1);
S   = zeros(3,3);
E   = zeros(3,3);
dE  = zeros(3,3);
Int = zeros(14,1);
e0  = 0.65;

S(1,1) = -pin;
S(2,2) = -pin;
S(3,3) = -pin;

inf(ii) = ID+1;

for kk = 1:1e3
    S0      = S;
    E0      = E;
    Int0    = Int;
    p0 = -trace(S0)/3;
    dE(1,1) = dire*randE(ID+1)*1e-6;
    det0    = 4*dE(1,1);
    det1    = -4*dE(1,1);
    for mm = 1:100000
        dE(2,2) = (det0+det1)/2;
        dE(3,3) = (det0+det1)/2;
        [S,Int,Lp,nor,Dir,Dre,Hp] = GetStressCycLiq(S0,dE,Int,e0);
        p1 = -trace(S)/3;
        if abs(p1-pin) <= 1e-4
            break
        end
        if (S(2,2)-S0(2,2)) > 0
            det1 = dE(2,2);
        else
            det0 = dE(2,2);
        end
    end
    E  = E0+dE;
    e0 = 1.65*exp(trace(E))-1;
    
    
    drn = ddot(-S0/p0,nor);
    den = ddot(-dE,nor);
    SaveData
    
end

sup(ii) = ID;

end

save('DataAxiCD','data_p0','data_r0','data_p1','data_r1','data_L','data_Dir','data_Dreg',...
    'data_Drer','data_H','data_dv','data_den','data_drn','data_nor',...
    'data_S0','data_S1','data_E0','data_dE','data_Int0','data_Int','data_dEp','inf','sup');

function [result]=ddot(A,B)
result = 0;
for ii = 1:3
   for jj = 1:3
      result = result + A(ii,jj) * B(ii,jj); 
   end
end
end