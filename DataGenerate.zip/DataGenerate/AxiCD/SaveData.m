ID              = ID+1;
dEp             = Lp*nor;
data_p0(ID,:)   = p0;
data_p1(ID,:)   = p1;
data_r0(ID,:)   = -[S0(1,1)+p0,S0(2,2)+p0,S0(3,3)+p0,S0(1,2),S0(2,3),S0(3,1)]/p0;
data_r1(ID,:)   = -[S(1,1)+p1,S(2,2)+p1,S(3,3)+p1,S(1,2),S(2,3),S(3,1)]/p1;
data_L(ID,:)    = Lp;
data_dv(ID,:)   = -trace(dE);
data_H(ID,:)    = Hp;
data_Dir(ID,:)  = Dir;
data_den(ID,:)  = den;
data_drn(ID,:)  = drn;
data_S0(ID,:)   = -[S0(1,1),S0(2,2),S0(3,3),S0(1,2),S0(2,3),S0(3,1)];
data_S1(ID,:)   = -[S(1,1),S(2,2),S(3,3),S(1,2),S(2,3),S(3,1)];
data_E0(ID,:)   = -[E0(1,1),E0(2,2),E0(3,3),E0(1,2),E0(2,3),E0(3,1)];
data_dE(ID,:)   = -[dE(1,1),dE(2,2),dE(3,3),dE(1,2),dE(2,3),dE(3,1)];
data_dEp(ID,:)  = [dEp(1,1),dEp(2,2),dEp(3,3),dEp(1,2),dEp(2,3),dEp(3,1)];
data_Int0(ID,:) = Int0';
data_Int(ID,:)  = Int';
data_nor(ID,:)  = [nor(1,1),nor(2,2),nor(3,3),nor(1,2),nor(2,3),nor(3,1)];
if Dre > 0
    data_Dreg(ID,:) = 0;
    data_Drer(ID,:) = Dre;
else
    data_Dreg(ID,:) = Dre;
    data_Drer(ID,:) = 0;
end