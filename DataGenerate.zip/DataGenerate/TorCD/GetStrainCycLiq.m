function [EInc,Int1,L,nor,Dre,Dir,H] = GetStrainCycLiq(Ein,Sin,SInc,Int0)
% ------------------------ %
%      Step0：定义参数
% ------------------------ %
pat  = 101;    % 标准大气压
pmin = 0.5;    % 液化状态平均应力
tol  = 1e-8;   % 容差
% 本构参数
G0     = 210;
kappa  = 0.01;
h      = 1.50;
M      = 1.10;
dre1   = 1.40;
dre2   = 30.0;
rdr    = 0.05;
eta    = 30.0;
dir    = 2.60;
lamdac = 0.0112;
ksi    = 0.715;
e0     = 0.78;
np     = 2.20;
nd     = 6.00;
ein    = 0.68;
% 初始应变应力
EVir0  = Int0(1);       % 第n步不可逆剪切体应变
EVre0  = Int0(2);       % 第n步可逆性剪切体应变
EVc0   = Int0(3);       % 第n步液化状态虚体应变
rmono0 = Int0(4);       % 第n步自上次加载方向后产生的广义剪应变
Mm0    = Int0(5);       % 第n步历史最大剪应力比
ain0   = zeros(3,3);    % 第n步前次应力反转点
for i = 1:3
   for j = 1:3
      ain0(i,j) =  Int0(5+3*(i-1)+j);
   end
end
% 内摩擦角
sinphi = 3*M/(M+6);                                   % 内摩擦角的正弦值
tanphi = sinphi/sqrt(1-sinphi*sinphi);                % 内摩擦角的正切值
Mfo    = 2*sqrt(3)*tanphi/sqrt(3+4*tanphi*tanphi);    % 扭剪应力状态下的峰值启动剪应力比，式(9b)

% ------------------------ %
%       Step1：初始化
% ------------------------ %
E0 = -1*Ein;                     % 第n步应变
S0 = -1*Sin;                     % 第n步应力
S1 = -1*(Sin+SInc);              % 第n+1步应力
% 计算偏应力
p0  = trace(S0)/3;              % 第n步平均应力
dS0 = S0-p0*eye(3);             % 第n步偏应力张量
r0  = dS0/p0;                   % 第n步偏应力比张量
p1  = trace(S1)/3;              % 第n+1步平均应力
dS1 = S1-p1*eye(3);             % 第n+1步偏应力张量
r1  = dS1/p1;                   % 第n+1步偏应力比张量
% 计算偏应变
EV0 = trace(E0);                % 第n步体应变
dE0 = E0-EV0/3*eye(3);          % 第n步偏应变张量
en  = (1+ein)*exp(-1*EV0)-1;    % 孔隙比
Mm1   = Mm0;                                               % 第n+1步历史最大剪应力比
EVcm  = -2*kappa/(1+ein)*(sqrt(p0/pat)-sqrt(pmin/pat));    % 变到pmin所需的压缩体应变，式(22)
ec    = e0-lamdac*(p0/pat)^ksi;                            % 当前围压下的临界孔隙比
psi   = en-ec;                                             % 砂土状态变量
Dre   = 0;
Dir   = 0;
H     = 0;

K   = (1+ein)/kappa*pat*sqrt((p0+p1)/2/pat);
G   = G0*pat*((2.973-ein)^2/(1+ein))*sqrt((p0+p1)/2/pat);    % 弹性剪切模量
% 初始化
rmono1 = rmono0;
ain1  = ain0;                  % 第n+1步前次应力反转点
EVir1 = EVir0;                 % 第n+1步不可逆剪切体应变
EVre1 = EVre0;                 % 第n+1步可逆性剪切体应变

eta0 = sqrt(3/2*ddot(r0,r0));                                 % 广义剪应力比

EVe = (p1-p0)/K;
dEe = (S1-S0)/2/G;

% 物态边界面计算
if ddot(r0,r0) < tol
    rsn      = zeros(3,3);                                 % 单位剪应力比张量
    rsn(1,1) = -1/sqrt(6);
    rsn(2,2) = -1/sqrt(6);
    rsn(3,3) = 2/sqrt(6);
else
    rsn      = r0/sqrt(ddot(r0,r0));
end
sin3t = GetS3th(rsn);
gthe = 1/(1+M/6*(sin3t+sin3t*sin3t)+(M-Mfo)/Mfo*(1-sin3t*sin3t));    % 物态边界面，式(7)
if (eta0/gthe) > Mm1
    Mm1 = eta0/gthe;                       % 更新历史最大剪应力比
end
if (eta0/gthe) > (M*exp(-1*np*psi)-tol)    % 判断是否达到峰值启动剪应力比，式(14)
    Mm1 = eta0/gthe;
end

% ------------------------ %
%   Step3：迭代计算rbar
% ------------------------ %
beta0 = 0;                       % 参数beta试算初值0，式(10)
beta1 = 1;                       % 参数beta试算初值1，式(10)
rbar0 = ain0+beta0*(r0-ain0);    % 当前应力点在偏应力空间中在历史最大剪应力比面上的投影0，式(10)
rbar1 = ain0+beta1*(r0-ain0);    % 当前应力点在偏应力空间中在历史最大剪应力比面上的投影1，式(10)
if (ddot(r0,r0) < tol) && (ddot(ain0,ain0) < tol)    % 刚开始加载
    nor      = zeros(3,3);       % 表征加载方向的单元范数偏张量
    nor(1,1) = -1/sqrt(6);
    nor(2,2) = -1/sqrt(6);
    nor(3,3) = 2/sqrt(6);
    rbar     = sqrt(2/3)*M*exp(-1*np*psi)*nor;      % 投影在峰值启动剪应力比面上
elseif sqrt(ddot(r0-ain0,r0-ain0)) < tol          % 刚发生应力反转
    nor  = rsn;
    rbar = sqrt(2/3)*Mm1*sin3t*nor;             % 投影在历史最大剪应力比面上
else
    if ddot(rbar0,rbar0) < tol                  % 避免初始迭代值除零
        beta0 = 0.01;
        rbar0 = ain0+beta0*(r0-ain0);
    end
    nor    = rbar0/sqrt(ddot(rbar0,rbar0));            % 计算征加载方向的单位范数偏张量，式(5)
    sin3t = GetS3th(nor);
    gthe = 1/(1+M/6*(sin3t+sin3t*sin3t)+(M-Mfo)/Mfo*(1-sin3t*sin3t));
    Fm0    = ddot((sqrt(2/3)*Mm1*gthe*nor-rbar0),nor);   % 计算取beta时的fm，式(6b)
    nor    = rbar1/sqrt(ddot(rbar1,rbar1));
    sin3t = GetS3th(nor);
    gthe = 1/(1+M/6*(sin3t+sin3t*sin3t)+(M-Mfo)/Mfo*(1-sin3t*sin3t));
    Fm1    = ddot((sqrt(2/3)*Mm1*gthe*nor-rbar1),nor);
    % 判断是否收敛
    if abs(Fm0) < 1e-5
        rbar = rbar0;
    elseif abs(Fm1) < 1e-5
        rbar = rbar1;
    else
        while (Fm0*Fm1>0)    % 确保beta的解落在beta0与beta1之间
            beta0      = beta1;
            beta1      = 2*beta1;
            rbar0      = ain0+beta0*(r0-ain0);
            rbar1      = ain0+beta1*(r0-ain0);
            nor    = rbar0/sqrt(ddot(rbar0,rbar0));
            sin3t = GetS3th(nor);
            gthe = 1/(1+M/6*(sin3t+sin3t*sin3t)+(M-Mfo)/Mfo*(1-sin3t*sin3t));
            Fm0    = ddot((sqrt(2/3)*Mm1*gthe*nor-rbar0),nor);
            nor    = rbar1/sqrt(ddot(rbar1,rbar1));
            sin3t = GetS3th(nor);
            gthe = 1/(1+M/6*(sin3t+sin3t*sin3t)+(M-Mfo)/Mfo*(1-sin3t*sin3t));
            Fm1    = ddot((sqrt(2/3)*Mm1*gthe*nor-rbar1),nor);
        end
        if abs(Fm0) < 1e-5
            rbar = rbar0;
        elseif abs(Fm1) < 1e-5
            rbar = rbar1;
        else
            beta  = beta1-Fm1*(beta1-beta0)/(Fm1-Fm0);
            rbar  = ain0+beta*(r0-ain0);
            nor   = rbar/sqrt(ddot(rbar,rbar));
            sin3t = GetS3th(nor);
            gthe  = 1/(1+M/6*(sin3t+sin3t*sin3t)+(M-Mfo)/Mfo*(1-sin3t*sin3t));
            Fm    = ddot((sqrt(2/3)*Mm1*gthe*nor-rbar),nor);
            while abs(Fm) > 1e-6    % 牛顿法迭代求解beta
                if (Fm*Fm1)<0
                    beta0 = beta1;
                    Fm0   = Fm1;
                    beta1 = beta;
                    Fm1   = Fm;
                else
                    Fm0   = Fm1*Fm0/(Fm1+Fm);
                    beta1 = beta;
                    Fm1   = Fm;
                end
                beta   = beta1-Fm1*(beta1-beta0)/(Fm1-Fm0);
                rbar   = ain0+beta*(r0-ain0);
                nor    = rbar/sqrt(ddot(rbar,rbar));
                sin3t = GetS3th(nor);
                gthe = 1/(1+M/6*(sin3t+sin3t*sin3t)+(M-Mfo)/Mfo*(1-sin3t*sin3t));
                Fm     = ddot((sqrt(2/3)*Mm1*gthe*nor-rbar),nor);
            end
        end
    end
end

% ------------------------ %
%    Step4：加卸载判断
% ------------------------ %
nor  = sqrt(3/2)*nor;                               % 王老师遗留的上古bug，不加这行一些参数不对
phi  = ddot((dS1-dS0),nor)-(p1-p0)*ddot(r0,nor);    % 假定不发生塑性加载，式(27)
phin = ddot(r1-r0,nor);                             % 若变形过小则跳过计算
if (phi < tol)||(phin < tol)                        % 发生卸载或变形过小
    rmono1 = 0;
    ain1   = r0;
    dEp    = zeros(3,3);
    EVp    = 0;
    L      = 0;
else
    rou    = sqrt(3/2)*sqrt(ddot(r0-ain0,r0-ain0));        % r和ain之间的距离
    roubar = sqrt(3/2)*sqrt(ddot(rbar-ain0,rbar-ain0));    % rbar和ain之间的距离
    H = 2/3*h*G*gthe*exp(-np*psi)*...
            (M*exp(-np*psi)/(Mm1+tol)*roubar/(rou+tol)-1); % 塑性模量，式(11)
    if (H < tol) && (H >= 0)                           % 避免塑性模量过小
        H = tol;
    end
    if (H > -tol) && (H < 0)
        H = -tol;
    end
    rd   = M*exp(nd*psi)/(Mm1+tol)*rbar;            % 当前应力在可逆性剪胀面上的投影
    Dre  = dre1*sqrt(2/3)*ddot(rd-r0,nor);    % 产生的可逆性剪胀率，式(19a)
    if EVir0 > tol
        chi = -dir*EVre0/EVir0;               % 控制可逆性剪胀释放过程的函数，式(20)
    else
        chi = 0;
    end
    if chi > 1
        chi = 1;
    end
    if Dre > 0
        Dre = (dre2*chi)^2/p0;                % 释放的可逆性剪胀率，式(19b)
        if -EVre0 < tol
            Dre = 0;
        end
%         if Dre > dre2
%             Dre = dre2;
%         end
    end
    if Dre > 0
        if psi < 0
            Dir = dir*exp(nd*psi-eta*EVir0)*(sqrt(2/3)*ddot(rd-r0,nor)*exp(chi)+...
                (rdr*(1-exp(nd*psi))/(rdr*(1-exp(nd*psi))+rmono1))^2);  % 不可逆性剪胀速率，式(21)
        else
            Dir = dir*exp(nd*psi-eta*EVir0)*(sqrt(2/3)*ddot((rd-r0),nor))*exp(chi);
        end
    else
        if psi < 0
            Dir = dir*exp(nd*psi-eta*EVir0)*((rdr*(1-exp(nd*psi))/(rdr*(1-exp(nd*psi))+rmono1))^2);
        else
            Dir = 0;
        end
    end
    D = Dir+Dre;    % 剪胀率，式(15)
    
    L   = (p1+p0)/2*ddot(r1-r0,nor)/H;
    EVp = L*D;
    dEp = L*nor;
    
    EVir1 = L*Dir+EVir0;
    EVre1 = L*Dre+EVre0;
    
    rmono1 = rmono1+L;
end

EVc1 = EVc0+EVe;
if EVc1 < EVcm
    EVc1 = EVcm;
end

Ee    = dEe+EVe/3*eye(3);
Ep    = dEp+EVp/3*eye(3);
EVc1  = EVc0-EVc1+EVe;

% ------------------------ %
%      Step6：输出数据
% ------------------------ %
EInc    = -1*(Ee+Ep);
Int1    = zeros(14,1);
Int1(1) = EVir1;
Int1(2) = EVre1;
Int1(3) = EVc1;
Int1(4) = rmono1;
Int1(5) = Mm1;
for i = 1:3
   for j = 1:3
      Int1(3*(i-1)+j+5) = ain1(i,j); 
   end
end

% ------------------------ %
%      函数：张量双点积
% ------------------------ %
function [result]=ddot(A,B)
result = 0;
for ii = 1:3
   for jj = 1:3
      result = result + A(ii,jj) * B(ii,jj); 
   end
end
end

% ------------------------ %
%       函数：罗德角
% ------------------------ %
function [sin3t]  = GetS3th(n)
paF   = n*n*n;
sin3t = -1*sqrt(6)*(paF(1,1)+paF(2,2)+paF(3,3));
if sin3t > 1
    sin3t = 1;
elseif sin3t < -1
    sin3t = -1;
end
end

end