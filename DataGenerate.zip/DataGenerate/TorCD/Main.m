clc
clear

epoch = 5000;

rng('shuffle');
randE = rand(9*(epoch+1),1);
dire  = 1;

inf = zeros(2,1);
sup = zeros(2,1);

ID = 0;

for ii = 1:2

pin = 100*(2*ii-1);
qin = pin*0.2;
S   = zeros(3,3);
E   = zeros(3,3);
dS  = zeros(3,3);
Int = zeros(14,1);
e0  = 0.65;

S(1,1) = -pin;
S(2,2) = -pin;
S(3,3) = -pin;

inf(ii) = ID+1;

for kk = 1:3e3
    S0      = S;
    E0      = E;
    Int0    = Int;
    dS(1,2) = dire*randE(ID+1)*5e-1;
    dS(2,1) = dire*randE(ID+1)*5e-1;
    [dE,Int,Lp,nor,Dre,Dir,Hp] = GetStrainCycLiq(E,S,dS,Int);
    S = S0+dS;
    E = E0+dE;
    p0 = -trace(S0)/3;
    p1 = -trace(S)/3;
    drn = ddot(-S0/p0,nor);
    den = ddot(-dE,nor);
    SaveData
    if abs(S(1,2)) >= qin
        dire = -dire;
    end
end

sup(ii) = ID;

end

clear p0 q0 kk ii E S E0 dE dS Lp0 nor0 Dre0 Dir0 ID

save('DataTorCD','data_p0','data_r0','data_p1','data_r1','data_L','data_Dir','data_Dreg',...
    'data_Drer','data_H','data_dv','data_den','data_drn','data_nor',...
    'data_S0','data_S1','data_E0','data_dE','data_Int0','data_Int','data_dEp','inf','sup');

function [result]=ddot(A,B)
result = 0;
for ii = 1:3
   for jj = 1:3
      result = result + A(ii,jj) * B(ii,jj); 
   end
end
end