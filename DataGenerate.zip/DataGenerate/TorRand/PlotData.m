clc
clear
load DataTorRand

mark = 2;
epoch = sup(mark)-inf(mark);
inf = inf(mark)-1;

ID = (1:(epoch+1))';

p1_plot  = zeros(epoch+1,1);
q1_plot  = zeros(epoch+1,1);

for kk = 1:(epoch+1)
    p1_plot(kk) = data_p1(inf+kk);
    q1_plot(kk) = data_p1(inf+kk)*data_r1(inf+kk,4);
    G           = 210*101*((2.973-0.65)^2/(1+0.65))*sqrt((data_p0(inf+kk)+data_p1(inf+kk))/2/101);
    K           = 1.65/0.01*101*sqrt((data_p0(inf+kk)+data_p1(inf+kk))/2/101);
    D           = data_Dreg(inf+kk)+data_Drer(inf+kk)+data_Dir(inf+kk);
    phi(kk,:)   = [(data_S1(inf+kk,1)-data_S0(inf+kk,1)-data_p1(inf+kk)+data_p0(inf+kk))-2*G*(data_dE(inf+kk,1)-data_dEp(inf+kk,1)-data_dv(inf+kk)/3),...
                   (data_S1(inf+kk,2)-data_S0(inf+kk,2)-data_p1(inf+kk)+data_p0(inf+kk))-2*G*(data_dE(inf+kk,2)-data_dEp(inf+kk,2)-data_dv(inf+kk)/3),...
                   (data_S1(inf+kk,3)-data_S0(inf+kk,3)-data_p1(inf+kk)+data_p0(inf+kk))-2*G*(data_dE(inf+kk,3)-data_dEp(inf+kk,3)-data_dv(inf+kk)/3),...
                   (data_S1(inf+kk,4)-data_S0(inf+kk,4))-2*G*(data_dE(inf+kk,4)-data_dEp(inf+kk,4)),...
                   (data_S1(inf+kk,5)-data_S0(inf+kk,5))-2*G*(data_dE(inf+kk,5)-data_dEp(inf+kk,5)),...
                   (data_S1(inf+kk,6)-data_S0(inf+kk,6))-2*G*(data_dE(inf+kk,6)-data_dEp(inf+kk,6))];
end

figure(1),plot(p1_plot,q1_plot);
figure(2),plot(ID,phi);
figure(3),plot(ID,q1_plot);