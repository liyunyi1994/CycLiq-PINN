clc
clear

rng('shuffle');
randE = rand(1e6,1);
dire  = 1;

inf = zeros(2,1);
sup = zeros(2,1);

ID = 0;

Lp  = 0;
Dre = 0;
Dir = 0;

for ii = 1:2

pin = 100*(2*ii-1);
qin = pin*0.2;
S   = zeros(3,3);
E   = zeros(3,3);
dE  = zeros(3,3);
Int = zeros(14,1);
e0  = 0.65;

S(1,1) = -pin;
S(2,2) = -pin;
S(3,3) = -pin;

inf(ii) = ID+1;

for kk = 1:1e4
    S0      = S;
    E0      = E;
    Int0    = Int;
    dE(1,2) = dire*randE(ID+1)*2e-5;
    dE(2,1) = dire*randE(ID+1)*2e-5;
    if (-trace(S0)/3) >= (0.5+1e-8)
%         dE(1,1) = (2*randE(1e6-ID)-0.5)*1e-6;
%         dE(2,2) = (2*randE(1e6-ID)-0.5)*1e-6;
%         dE(3,3) = (2*randE(1e6-ID)-0.5)*1e-6;
        dEP = Lp*(Dre+Dir);
        if abs(dEP) > 6e-6
            dEP = 6e-6*dEP/abs(dEP);
        end
        dE(1,1) = randE(1e6-ID)/3*dEP;
        dE(2,2) = randE(1e6-ID)/3*dEP;
        dE(3,3) = randE(1e6-ID)/3*dEP;
    end
    [S,Int,Lp,nor,Dir,Dre,Hp] = GetStressCycLiq(S0,dE,Int0,e0);
    E  = E0+dE;
    e0 = 1.65*exp(trace(E))-1;
    p0 = -trace(S0)/3;
    p1 = -trace(S)/3;
    if (p0 >= (0.5+1e-8)) && (p1 >= (0.5+1e-8))
        drn = ddot(-S0/p0,nor);
        den = ddot(-dE,nor);
        SaveData
    elseif (p0 >= (0.5+1e-8)) && (p1 < (0.5+1e-8))
        Lp  = (2*0.01/1.65*(sqrt(p0/101)-sqrt(0.5/101))-trace(dE))/(Dre+Dir);
        drn = ddot(-S0/p0,nor);
        G   = 210*((2.973-0.65)^2/(1+0.65))*sqrt(101)*sqrt((p0+p1)/2);
        den = ((p1-p0)*drn+(3*G+Hp)*Lp)/(2*G);
        SaveData
    elseif (p0 < (0.5+1e-8)) && (p1 >= (0.5+1e-8))
        Lp  = Lp-(-trace(dE)-Int(3))/(Dre+Dir);
        drn = ddot(-S0/p0,nor);
        G   = 210*((2.973-0.65)^2/(1+0.65))*sqrt(101)*sqrt((p0+p1)/2);
        den = ((p1-p0)*drn+(3*G+Hp)*Lp)/(2*G);
        SaveData
    end
    if abs(S(1,2)) >= qin
        dire = -dire;
        if abs(S0(1,2)) >= qin
            dire = -dire;
        end
    end
end

sup(ii) = ID;

end

save('DataTorRand','data_p0','data_r0','data_p1','data_r1','data_L','data_Dir','data_Dreg',...
    'data_Drer','data_H','data_dv','data_den','data_drn','data_nor',...
    'data_S0','data_S1','data_E0','data_dE','data_Int0','data_Int','data_dEp','inf','sup');

function [result]=ddot(A,B)
result = 0;
for ii = 1:3
   for jj = 1:3
      result = result + A(ii,jj) * B(ii,jj); 
   end
end
end